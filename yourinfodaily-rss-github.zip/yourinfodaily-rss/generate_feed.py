#!/usr/bin/env python3
"""
Crawl the YourInfoDaily blog and generate a standards-compliant RSS 2.0 feed.

The blog is currently a page that lists posts in reverse chronological order.
This crawler uses the page's repeated "Published on" + heading structure rather
than relying on a CMS API, so it can keep working as new submissions appear.
"""

from __future__ import annotations

import html
import os
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from email.utils import format_datetime
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup
from xml.etree.ElementTree import Element, SubElement, ElementTree

BLOG_URL = os.getenv("BLOG_URL", "https://www.yourinfodaily.com/blog")
SITE_URL = os.getenv("SITE_URL", "https://www.yourinfodaily.com")
FEED_URL = os.getenv("FEED_URL", "https://YOUR-GITHUB-USERNAME.github.io/yourinfodaily-rss/feed.xml")
MAX_ITEMS = int(os.getenv("MAX_ITEMS", "50"))
OUTPUT = os.getenv("OUTPUT", "feed.xml")

HEADERS = {
    "User-Agent": "YourInfoDaily-RSS/1.0 (+https://www.yourinfodaily.com/)",
    "Accept": "text/html,application/xhtml+xml",
}

@dataclass
class Post:
    title: str
    url: str
    published: datetime
    description: str


def clean_text(value: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(value or "")).strip()


def parse_date(value: str) -> datetime:
    # YourInfoDaily currently renders dates like "August 24, 2026".
    return datetime.strptime(clean_text(value), "%B %d, %Y").replace(tzinfo=timezone.utc)


def is_same_site(url: str) -> bool:
    host = urlparse(url).netloc.lower()
    return host in {"www.yourinfodaily.com", "yourinfodaily.com"}


def fetch_html(url: str) -> BeautifulSoup:
    response = requests.get(url, headers=HEADERS, timeout=30)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")


def find_posts(soup: BeautifulSoup) -> list[Post]:
    posts: list[Post] = []
    seen_urls: set[str] = set()

    # The current page repeats:
    # Published on -> date -> H2 -> article link -> category -> article text.
    for marker in soup.find_all(string=re.compile(r"^\s*Published on\s*$", re.I)):
        date_node = marker.parent.find_next(string=re.compile(r"\b[A-Z][a-z]+\s+\d{1,2},\s+\d{4}\b"))
        if not date_node:
            continue

        try:
            published = parse_date(str(date_node))
        except ValueError:
            continue

        heading = None
        # Look forward for the first H1/H2/H3 that contains an internal link.
        for node in marker.parent.find_all_next(["h1", "h2", "h3"], limit=8):
            link = node.find("a", href=True)
            if link and clean_text(link.get_text(" ", strip=True)):
                heading = node
                break

        if not heading:
            continue

        link = heading.find("a", href=True)
        url = urljoin(BLOG_URL, link["href"])
        title = clean_text(link.get_text(" ", strip=True))

        if not title or url in seen_urls or not is_same_site(url):
            continue

        # Collect a short description from the content following the heading.
        description_parts: list[str] = []
        for node in heading.find_all_next(["p", "div"], limit=15):
            text = clean_text(node.get_text(" ", strip=True))
            if text and text.lower() not in {"business", "art", "news"}:
                description_parts.append(text)
            if sum(len(x) for x in description_parts) >= 500:
                break

        description = clean_text(" ".join(description_parts))[:600]
        posts.append(Post(title, url, published, description))
        seen_urls.add(url)

    # Newest first; duplicate dates are handled by the source order.
    posts.sort(key=lambda p: p.published, reverse=True)
    return posts[:MAX_ITEMS]


def xml_escape(value: str) -> str:
    return html.escape(value, quote=True)


def generate(posts: list[Post]) -> None:
    rss = Element("rss", {"version": "2.0"})
    channel = SubElement(rss, "channel")

    SubElement(channel, "title").text = "YourInfoDaily"
    SubElement(channel, "link").text = SITE_URL
    SubElement(channel, "description").text = (
        "Startup funding news, business news, music industry press, arts and culture."
    )
    SubElement(channel, "language").text = "en-us"
    SubElement(channel, "lastBuildDate").text = format_datetime(datetime.now(timezone.utc))
    SubElement(channel, "generator").text = "YourInfoDaily RSS Crawler"

    for post in posts:
        item = SubElement(channel, "item")
        SubElement(item, "title").text = post.title
        SubElement(item, "link").text = post.url
        SubElement(item, "guid", {"isPermaLink": "true"}).text = post.url
        SubElement(item, "pubDate").text = format_datetime(post.published)
        SubElement(item, "description").text = post.description

    # ElementTree writes valid XML and escapes content safely.
    ElementTree(rss).write(OUTPUT, encoding="utf-8", xml_declaration=True)


def main() -> None:
    soup = fetch_html(BLOG_URL)
    posts = find_posts(soup)

    if not posts:
        raise RuntimeError(
            "No posts found. The YourInfoDaily blog HTML structure may have changed."
        )

    generate(posts)
    print(f"Generated {OUTPUT} with {len(posts)} items.")


if __name__ == "__main__":
    main()
