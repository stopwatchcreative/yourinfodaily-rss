# YourInfoDaily RSS Feed

Automatically crawls https://www.yourinfodaily.com/blog and generates an RSS 2.0 feed.

## Setup

1. Create a GitHub repository named `yourinfodaily-rss`.
2. Upload these files.
3. Replace `YOUR-GITHUB-USERNAME` in `.github/workflows/update-feed.yml` with your GitHub username.
4. Enable GitHub Pages:
   - Repository → Settings → Pages
   - Source: **Deploy from a branch**
   - Branch: **main**
   - Folder: **/(root)**
5. Run **Actions → Update YourInfoDaily RSS Feed → Run workflow** once.
6. Your RSS feed will be available at:

`https://YOUR-GITHUB-USERNAME.github.io/yourinfodaily-rss/feed.xml`

## Automatic updates

GitHub Actions checks the YourInfoDaily blog every 3 hours and commits a new
`feed.xml` only when the feed has changed.

## What the crawler extracts

- Article title
- Article URL
- Publication date
- Short description/excerpt

The crawler currently keeps the newest 50 posts.

## If the blog HTML changes

The parser is intentionally based on the current repeated `Published on` +
heading pattern. If YourInfoDaily changes its page structure, update
`find_posts()` in `generate_feed.py`.
